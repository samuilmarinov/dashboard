<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

<div id="toolbar">
</div>
                 
<table id="datavehicles" class="display" style="margin-top:4rem !important;">
  <thead>
    <tr>
      <th></th>
      <td></td>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
<tfoot style="border-bottom: 1px solid black; position:absolute; top:0; border-top: 1px solid black; width:100%;">
      <th style="border-top:0;" class="one"></th>
      <th style="border-top:0;" class="two"></td>
      <th style="border-top:0;" class="three">
      
      </th>
      <th style="border-top:0;" class="four"></th>
      <th style="border-top:0;" class="five"></th>
      <th style="border-top:0;" class="six"></th>
      <th style="border-top:0;" class="seven"></th>
      <th style="border-top:0;" class="eight"></th>
      <th style="border-top:0;" class="nine"></th>
      <th style="border-top:0;" class="ten"></th>
      <th style="border-top:0;" class="eleven"></th>
</tfoot>
</table>
     <form action="<?php echo e(route('vehicles.search2')); ?>" method="GET" role="search" class="form-inline my-2 my-lg-0">
    
    <div class="input-group">
            <input class="form-control mr-sm-2" name="brands" type="search" placeholder="Search Vehicles" value="<?php echo e(Request::get('brands')); ?>" aria-label="Search">
            <button type="submit" class="btn btn-outline-success my-2 my-sm-0">
                Search Vehicles
            </button>
        </span>
    </div>
    </form>                
<script>
$("body").on('change','.js-switch', function () {
        let status = $(this).prop('checked') === true ? 1 : 0;
        let vehicleId = $(this).data('id');
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '<?php echo e(route('vehicles.update.status')); ?>',
            data: {'status': status, 'vehicle_id': vehicleId},
            success: function (data) {
                console.log(data.message);
                    toastr.options.closeButton = true;
                    toastr.options.closeMethod = 'fadeOut';
                    toastr.options.closeDuration = 100;
                    toastr.success(data.message);
            }
        });
});
</script>

<script>
(function( $ ){
$(document).ready(function() {


  var table = $('#datavehicles').DataTable({
    responsive: true,
    select: false,
    ordering: true,
    processing: false,
    serverSide: false,
    ajax: {
            url: '<?php echo e(route('vehicles.searches')); ?>',
            method: 'GET',
            type: 'GET',
            data: function (d) {
                     d.from_date = $("#from_date").val();
                     d.to_date = $("#to_date").val();
            }
    },
    columns: [
      { data: "id", title: "ID", orderable: true,  },
      { data: "imageurl", title: "Image", orderable: false, searchable: false },
      { data: "vehiclebrand", title: "Brand", orderable: true, },
      { data: "vehiclemodel", title: "Model", orderable: true, },
      { data: "vehiclebodywork", title: "Bodywork", orderable: true, },
      { data: "vehicleengine", title: "Engine", orderable: true, },
      { data: "vehiclecolor", title: "Color", orderable: true, },
      { data: "created_at", title: "Created at", orderable: false, searchable: false },
      { data: "updated_at", title: "Updated at", orderable: false, searchable: false },
      { data: 'status', title: 'Status', orderable: false, searchable: false, width: '10px', sClass: "selectCol" },
      { data: 'action', title: 'Action', orderable: false, searchable: false, width: '10px', sClass: "selectCol" },
     
    ],
    fnDrawCallback: function() { jQuery('.my_switch').bootstrapToggle(); },
      initComplete: function () {
          var n = 0;
            this.api().columns().every( function (n) {
                n++;
                var column = this;
                var select = $('<select name="filter-vehicle-'+n+'" id="filter-vehicle-'+n+'"><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
                var j = 1;
                column.data().unique().sort().each( function ( d, j ) {
                    j++;
                    select.append( '<option id="brandoption_'+d+'" data-brand="'+j+'" value="'+d+'">'+d+'</option>' )
                } );
            } );
        }
    });


            $('#filter-vehicle-4').empty();

            $('.input-daterange').datepicker({
                 dateFormat: 'dd-mm-yy',
                 autoclose: true,
                 todayHighlight: true
            });

            $('#dateSearch').on('click', function() {
                //console.log('search');
                table.draw();
            });
        
});

})( jQuery );
</script>
<script type="text/javascript">
(function( $ ){
$("body").on('change','select[name="filter-vehicle-3"]', function () {
             
               //var brandID = jQuery(this).val;
               
               var brandID = jQuery(this).find(':selected').attr('data-brand');

               if(brandID)
               {
                  jQuery.ajax({
                     url : '/vehicles/getmodels/' +brandID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="filter-vehicle-4"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="filter-vehicle-4"]').append('<option data-model="'+ key +'" value="'+ value +'">'+ value +'</option>');
                        });
                       $('select[name="filter-vehicle-4"]').css("visibility", "visible");
                     }
                  });
               }
               else
               {
                  $('select[name="filter-vehicle-4"]').empty();
               }
});

document.addEventListener('DOMContentLoaded', function() {
   //
}, false);

})( jQuery );
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/webinteractive/resources/views/vehicles/search2.blade.php ENDPATH**/ ?>