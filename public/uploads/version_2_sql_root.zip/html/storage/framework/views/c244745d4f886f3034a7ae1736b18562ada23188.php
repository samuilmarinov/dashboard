<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Colors</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('colors.create')); ?>"> Create New Color</a>
                
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
 <table class="table table-bordered" id="table" style="margin-top:1rem; border:0 !important;">
    
        <thead>
            <tr>
                <th data-field="ID" data-checkbox="false">Color ID</th>
                <th data-field="name" data-filter-control="select" data-sortable="true">Name</th>
                <th data-field="metallic" data-sortable="true">Metallic</th>
                <th data-field="created_at" data-sortable="true">Date Created</th>
                <th data-field="updated_at" data-sortable="true">Date Modified</th>
                <th data-field="status" data-sortable="true">Status</th>
                <th width="280px">Action</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($color->id); ?></td>
            <td><?php echo e($color->name); ?></td>
            <td>
            <input type="checkbox" data-id="<?php echo e($color->id); ?>" name="metallic" class="js-switch color-finish" <?php echo e($color->metallic == 1 ? 'checked' : ''); ?>>
            </td>
            <td><?php echo e($color->created_at); ?></td>
            <td><?php echo e($color->updated_at); ?></td>
            <td>
            <input type="checkbox" data-id="<?php echo e($color->id); ?>" name="status" class="js-switch status-update" <?php echo e($color->status == 1 ? 'checked' : ''); ?>>
            </td>
            <td>
                <form action="<?php echo e(route('colors.destroy',$color->id)); ?>" method="POST">

                    <a class="btn btn-primary" href="<?php echo e(route('colors.edit',$color->id)); ?>">Edit</a>

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php echo $colors->links(); ?>


<script>
$("body").on('change','.status-update', function () {
        let status = $(this).prop('checked') === true ? 1 : 0;
        let colorId = $(this).data('id');
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '<?php echo e(route('colors.update.status')); ?>',
            data: {'status': status, 'color_id': colorId},
            success: function (data) {
                console.log(data.message);
                    toastr.options.closeButton = true;
                    toastr.options.closeMethod = 'fadeOut';
                    toastr.options.closeDuration = 100;
                    toastr.success(data.message);
            }
        });
});
</script>
<script>
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
  var switchery = new Switchery(html);
});
</script>
<script>
$("body").on('change','.color-finish', function () {
        let metallic = $(this).prop('checked') === true ? 1 : 0;
        let finishId = $(this).data('id');
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '<?php echo e(route('colors.update.finish')); ?>',
            data: {'metallic': metallic, 'color_id': finishId},
            success: function (data) {
                console.log(data.message);
                    toastr.options.closeButton = true;
                    toastr.options.closeMethod = 'fadeOut';
                    toastr.options.closeDuration = 100;
                    toastr.success(data.message);
                    // window.location.replace("/colors"); 
                    location.reload();
            }
        });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/sammardev3.xyz/html/resources/views/colors/index.blade.php ENDPATH**/ ?>