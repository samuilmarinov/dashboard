<?php $__env->startSection('content'); ?>
<div class="container">
<?php $i = 0; ?>
<?php if(isset($details)): ?>
    <p> The Search results for your query <b> <?php echo e($query); ?> </b> are :</p>
    <h2>Vehicle details</h2>
    <table class="table table-bordered" id="table" data-toggle="table" data-search="false" data-filter-control="true" data-show-export="false" data-click-to-select="false" data-toolbar="#toolbar">
         <thead>
            <tr>
                <th data-field="ID" data-checkbox="false">Search Index</th>
                <th>Image</th>
                <th data-field="brand" data-filter-control="select" data-sortable="false">
                <label for="model_id">Brand</label>
                <div class="fht-cell">
                <div class="filter-control">
                <select name="brand_id" id="filterbrand" class="form-control  form-controlbootstrap-table-filter-control-brand">
                <option>Brand</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($brand->status == 1): ?>
                    <option value="<?php echo e($brand->name); ?>">
                        <?php echo e($brand->name); ?>

                    </option>
                <?php endif; ?>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                </div>
                </div>
                
                </th>
                <th data-field="model" data-filter-control="select" data-sortable="false">
                <label for="model_id">Model</label>
                <div class="fht-cell">
                <div class="filter-control">
                <select name="model_id" id="filtermodel" class="form-control bootstrap-table-filter-control-model">
                <option>--Model--</option>
                </select>
                </div>
                </div>   
                </th>
                <th data-field="bodywork" data-filter-control="select" data-sortable="true">Bodywork</th>
                <th data-field="engine" data-filter-control="select" data-sortable="true">Engine</th>
                <th data-field="color" data-filter-control="select" data-sortable="true">Color</th>
                <th data-field="created_at" data-sortable="true">Date Created</th>
                <th data-field="updated_at" data-sortable="true">Date Modified</th>
                 <th data-field="status" data-sortable="true">Status</th>
                <th width="280px">Action</th>
            </tr>
        </thead>
  
            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e(++$i); ?></td>
            <td><img src="/uploads/images/<?php echo e($vehicle->imageurl); ?>" height="75" width="75" alt="" /></td>
            <td><?php echo e($vehicle->brand_id); ?></td>
            <td><?php echo e($vehicle->model_id); ?></td>
            <td><?php echo e($vehicle->bodywork_id); ?></td>
            <td><?php echo e($vehicle->engine_id); ?></td>
            <td><?php echo e($vehicle->color_id); ?></td>
            <td><?php echo e($vehicle->created_at); ?></td>
            <td><?php echo e($vehicle->updated_at); ?></td>
            <td>
            <input type="checkbox" data-id="<?php echo e($vehicle->id); ?>" name="status" class="js-switch" <?php echo e($vehicle->status == 1 ? 'checked' : ''); ?>>
            </td>
            <td>
                <form action="<?php echo e(route('vehicles.destroy',$vehicle->id)); ?>" method="POST">

                    <a class="btn btn-primary" href="<?php echo e(route('vehicles.edit',$vehicle->id)); ?>">Edit</a>

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
    </table>
    <?php else: ?>
    <div>
        <h2>No vehicles found</h2>
    </div>
    <?php endif; ?>
</div>
<script type="text/javascript">
$("body").on('change','select[name="brand_id"]', function () {
               var brandID = jQuery(this).val();
               if(brandID)
               {
                  jQuery.ajax({
                     url : '/vehicles/getmodels/' +brandID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="model_id"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="model_id"]').append('<option value="'+ value +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="model_id"]').empty();
               }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/samuilmarinovdev2.co.uk/html/react-rickandmorty/resources/views/vehicles/search.blade.php ENDPATH**/ ?>