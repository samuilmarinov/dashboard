<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<div id="toolbar">
     
</div>
                       
<table id="datavehicles" class="display" style="width:100%">
  <thead>
    <tr>
      <th>#</th>
      <th>vehiclebrand</th>
      <th>vehiclemodel</th>
      <th>vehicleengine</th>
      <th>vehiclebodywork</th>
      <th>vehiclecolor</th>
      <th>created</th>
      <th>updated</th>
      <th>action</th>
    </tr>
  </thead>
<tfoot>
			<th>#</th>
      <th>vehiclebrand</th>
      <th>vehiclemodel</th>
      <th>vehicleengine</th>
      <th>vehiclebodywork</th>
      <th>vehiclecolor</th>
</tfoot>
</table>
                     <div class="row">
                      
                       <form action="<?php echo e(route('vehicles.testdate')); ?>" method="GET">
                            <div class="col-xs-4 form-inline" style="position: absolute; z-index: 2;">
                                <div class="input-daterange input-group" id="datepicker">
                                    
                                     <input type="text" id="from_date" name="from_date" class="input-sm form-control" name="from_date" value="<?php echo e(Request::get('from_date')); ?>" />
                                    <span class="input-group-addon">to</span>
                                    
                                    <input type="text" id="to_date" name="to_date" class="input-sm form-control" name="to_date" value="<?php echo e(Request::get('to_date')); ?>"/>
                                </div>
                                <button type="submit" id="dateSearch" class="btn btn-sm btn-primary">Search</button>
                            </div>
                      </form>
                     

                    </div>
<script>
(function( $ ){
$(document).ready(function() {
  var table = $('#datavehicles').DataTable({
    responsive: true,
    select: true,
    ordering: true,
    processing: false,
    serverSide: false,
 // ajax: '<?php echo e(route('vehicles.getindexdata')); ?>',
    ajax: {
            url: '<?php echo e(route('vehicles.getindexdata')); ?>',
            method: 'GET',
            type: 'GET',
            data: function (d) {
                     d.from_date = $("#from_date").val();
                     d.to_date = $("#to_date").val();
            }
    },
    columns: [
      { data: "id", name: "id", orderable: true,  },
      { data: "vehiclebrand", title: "Brand", orderable: true, },
      { data: "vehiclemodel", title: "Model", orderable: true, },
      { data: "vehiclebodywork", title: "Bodywork", orderable: true, },
      { data: "vehicleengine", title: "Engine", orderable: true, },
      { data: "vehiclecolor", title: "Color", orderable: true, },
      { data: "created_at", title: "Created at", },
      { data: "updated_at", title: "Updated at", },
      { data: 'action', title: 'action', orderable: false, searchable: false, width: '10px', sClass: "selectCol" },
    ],
      initComplete: function () {
            this.api().columns().every( function () {
                var column = this;
                var select = $('<select><option value=""></option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        }
    }); 

            $('.input-daterange').datepicker({
                dateFormat: 'dd-mm-yy',
                 autoclose: true,
                 todayHighlight: true
            });

            $('#dateSearch').on('click', function() {
                table.draw();
            });

   
});
})( jQuery );
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/webinteractive/resources/views/vehicles/testdate.blade.php ENDPATH**/ ?>