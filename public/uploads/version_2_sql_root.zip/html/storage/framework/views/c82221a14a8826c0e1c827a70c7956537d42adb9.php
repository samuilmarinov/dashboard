<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Webinteractive</title>
        <link rel="stylesheet" href="/css/bootstrap/bootstrap.min.css" crossorigin="anonymous">
       
        <script src="/js/jquery/jquery-latest.js"></script>
        <link rel="stylesheet" href="/css/toastr/toastr.min.css">
        <script src="/js/toastr/toastr.min.js"></script>
    
        <script src="/js/bootstrap/bootstrap-table.min.js"></script>
        <link rel="stylesheet" href="/css/bootstrap/bootstrap-table.min.css">
        <link rel="stylesheet" type="text/css" href="/css/bootstrap/bootstrap-table-filter-control.min.css">
        <script src="/js/bootstrap/bootstrap-table-filter-control.js"></script>


        <link rel="stylesheet" href="/css/switchery/switchery.min.css">
        <script src="/js/switchery/switchery.min.js"></script>
        <link href="<?php echo e(asset('css/styles.css?v=1.1')); ?>" rel="stylesheet">
    </head>
    <body>
        <?php echo $__env->make('nav.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="flex-top position-ref full-height">
            <div style="padding: 0 50px; text-align: left;" class="content">
           
                    <?php echo $__env->yieldContent('content'); ?>
                 
    
            </div>
        </div>

        <footer style="width:100%;" id="footer" class="footer">
        ©2021
        </footer>
        <script>
        setTimeout(function() {
            $('.alert').fadeOut('fast');
        }, 3000); 
        </script>
    </body>
</html><?php /**PATH /Applications/MAMP/htdocs/webinteractive/resources/views/layout.blade.php ENDPATH**/ ?>