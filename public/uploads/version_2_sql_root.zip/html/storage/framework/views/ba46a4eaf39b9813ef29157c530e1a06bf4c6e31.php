<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Brands</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('brands.create')); ?>"> Create New Brand</a>
                
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
 <table class="table table-bordered" id="table" style="margin-top:1rem; border:0 !important;">
    
        <thead>
            <tr>
                <th data-field="ID" data-checkbox="false">Brand ID</th>
                <th data-field="name" data-filter-control="select" data-sortable="true">Name</th>
                <th data-field="created_at" data-sortable="true">Date Created</th>
                <th data-field="updated_at" data-sortable="true">Date Modified</th>
                <th data-field="status" data-sortable="true">Status</th>
                <th width="280px">Action</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($brand->id); ?></td>
            <td><?php echo e($brand->name); ?></td>
            <td><?php echo e($brand->created_at); ?></td>
            <td><?php echo e($brand->updated_at); ?></td>
            <td>
            <input type="checkbox" data-id="<?php echo e($brand->id); ?>" name="status" class="js-switch" <?php echo e($brand->status == 1 ? 'checked' : ''); ?>>
            </td>
            <td>
                <form action="<?php echo e(route('brands.destroy',$brand->id)); ?>" method="POST">

                    <a class="btn btn-primary" href="<?php echo e(route('brands.edit',$brand->id)); ?>">Edit</a>

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php echo $brands->links(); ?>

<script>
$("body").on('change','.js-switch', function () {
        let status = $(this).prop('checked') === true ? 1 : 0;
        let brandId = $(this).data('id');
        $.ajax({
            type: "GET",
            dataType: "json",
            url: '<?php echo e(route('brands.update.status')); ?>',
            data: {'status': status, 'brand_id': brandId},
            success: function (data) {
                console.log(data.message);
                    toastr.options.closeButton = true;
                    toastr.options.closeMethod = 'fadeOut';
                    toastr.options.closeDuration = 100;
                    toastr.success(data.message);
            }
        });
});
</script>
<script>
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
  var switchery = new Switchery(html);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/sammardev3.xyz/html/resources/views/brands/index.blade.php ENDPATH**/ ?>