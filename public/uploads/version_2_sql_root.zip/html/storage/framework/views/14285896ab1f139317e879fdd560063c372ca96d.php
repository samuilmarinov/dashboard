<form action="<?php echo e(route('search')); ?>" method="GET">
    <input type="text" name="search" required/>
    <button type="submit">Search</button>
</form>
<?php if($vehicles->isNotEmpty()): ?>
    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post-list">
            <p><?php echo e($vehicle->brand_id); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
    <div>
        <h2>No vehicles found</h2>
    </div>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/webinteractive/resources/views/vehicles/searchresult.blade.php ENDPATH**/ ?>