<?php $__env->startSection('content'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.7.0/tinymce.min.js" referrerpolicy="origin"></script>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit Vehicle</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary back" href="<?php echo e(route('vehicles.index')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('vehicles.update',$vehicle->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

         <div class="row">
            
            <div class="col-xs-12 col-sm-12 col-md-12 statusedit">
             <select name="brand_id" class="form-control">
                <option value="<?php echo e($vehicle->brand_id); ?>"><?php echo e($vehicle->brand_id); ?></option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($brand->name != $vehicle->brand_id && $brand->status == 1): ?>
                    <option value="<?php echo e($brand->name); ?>">
                        <?php echo e($brand->name); ?>

                    </option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 statusedit">
            <div class="form-group">
                    <label for="model_id">Select Model</label>
                    <select name="model_id" class="form-control">
                    <option>--Model--</option>
                    </select>
            </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 statusedit">
             <select name="bodywork_id" class="form-control">
                <option value="<?php echo e($vehicle->bodywork_id); ?>"><?php echo e($vehicle->bodywork_id); ?></option>
                <?php $__currentLoopData = $bodyworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bodywork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($bodywork->name != $vehicle->bodywork_id && $bodywork->status == 1): ?>
                    <option value="<?php echo e($bodywork->name); ?>">
                        <?php echo e($bodywork->name); ?>

                    </option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 statusedit">
             <select name="engine_id" class="form-control">
                <option value="<?php echo e($vehicle->engine_id); ?>"><?php echo e($vehicle->engine_id); ?></option>
                <?php $__currentLoopData = $engines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($engine->name != $vehicle->engine_id && $engine->status == 1): ?>
                    <option value="<?php echo e($engine->name); ?>">
                        <?php echo e($engine->name); ?>

                    </option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 statusedit">
             <select name="color_id" class="form-control">
                <option value="<?php echo e($vehicle->color_id); ?>"><?php echo e($vehicle->color_id); ?></option>
                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($color->name != $vehicle->color_id && $color->status == 1): ?>
                    <option value="<?php echo e($color->name); ?>">
                        <?php echo e($color->name); ?>

                    </option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
            

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Version:</strong>
                    <input type="text" name="version" value="<?php echo e($vehicle->version); ?>" class="form-control" placeholder="Version">
                </div>
            </div>
    
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Info:</strong>
                    <textarea name="info" rows="10" cols="40" class="form-control tinymce-editor">
                        <?php echo e($vehicle->info); ?>

                    </textarea>

                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Image:</strong>
                 <input id="imageupload" name="image" type="file" class="form-control" placeholder="Image">
                 <input id="image" type="text" name="imageurl" value="<?php echo e($vehicle->imageurl); ?>" class="form-control zindex" placeholder="Image">
                <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                  <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group">
              <img src="/uploads/images/<?php echo e($vehicle->imageurl); ?>" height="75" width="75" alt="" />
            </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 statusedit">
            <label for="metallic">Status:</label>
                    <select name="status" id="status">
                        <?php if($vehicle->status == 1): ?>
                        <option value="1">Active</option>
                        <option value="0">Disabled</option>
                        <?php else: ?>
                        <option value="0">Disabled</option>
                        <option value="1">Active</option>
                        <?php endif; ?>
                    </select>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-left submit">
              <button type="submit" class="btn btn-primary submit">Submit</button>
            </div>
        </div>

    </form>

<script type="text/javascript">
    jQuery(document).ready(function ()
    {
            jQuery('select[name="brand_id"]').on('change',function(){
               var brandID = jQuery(this).val();
               if(brandID)
               {
                  jQuery.ajax({
                     url : '/vehicles/getmodels/' +brandID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="model_id"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="model_id"]').append('<option value="'+ value +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="model_id"]').empty();
               }
            });
    });
</script>
<script>    
document.getElementById('imageupload').onchange = uploadOnChange;
function uploadOnChange() {
  var filename = this.value;
  var lastIndex = filename.lastIndexOf("\\");
  if (lastIndex >= 0) {
    filename = filename.substring(lastIndex + 1);
  }
  document.getElementById('image').value = filename;
}
</script>
<script>
$(window).load(function() {

               var brandID = jQuery('select[name="brand_id"]').val();
               if(brandID)
               {
                  jQuery.ajax({
                     url : '/vehicles/getmodels/' +brandID,
                     type : "GET",
                     dataType : "json",
                     success:function(data)
                     {
                        console.log(data);
                        jQuery('select[name="model_id"]').empty();
                        jQuery.each(data, function(key,value){
                           $('select[name="model_id"]').append('<option value="'+ value +'">'+ value +'</option>');
                        });
                     }
                  });
               }
               else
               {
                  $('select[name="model_id"]').empty();
               }
       

});
</script>
<script type="text/javascript">
        tinymce.init({
            selector: 'textarea.tinymce-editor',
            height: 100,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'undo redo | formatselect | ' +
                'bold italic backcolor | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat | help',
            content_css: '//www.tiny.cloud/css/codepen.min.css'
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/samuilmarinovdev2.co.uk/html/react-rickandmorty/resources/views/vehicles/edit.blade.php ENDPATH**/ ?>