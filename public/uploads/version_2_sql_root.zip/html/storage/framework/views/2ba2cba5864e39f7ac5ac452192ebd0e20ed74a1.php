<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="/">Webinteractive</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">Dashboard <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item <?php echo e(Request::segment(1) === 'vehicles' ? 'active' : null); ?>">
        <a class="nav-link" href="<?php echo e(url('vehicles')); ?>">Vehicles</a>
      </li>
      <li class="nav-item <?php echo e(Request::segment(1) === 'brands' ? 'active' : null); ?>">
        <a class="nav-link" href="<?php echo e(url('brands')); ?>">Brands</a>
      </li>
      <li class="nav-item <?php echo e(Request::segment(1) === 'vehiclemodels' ? 'active' : null); ?>">
        <a class="nav-link" href="<?php echo e(url('vehiclemodels')); ?>">Vehicle Models</a>
      </li>
      <li class="nav-item <?php echo e(Request::segment(1) === 'bodyworks' ? 'active' : null); ?>">
        <a class="nav-link" href="<?php echo e(url('bodyworks')); ?>">Bodyworks</a>
      </li>
      <li class="nav-item <?php echo e(Request::segment(1) === 'engines' ? 'active' : null); ?>">
        <a class="nav-link" href="<?php echo e(url('engines')); ?>">Engines</a>
      </li>
      <li class="nav-item <?php echo e(Request::segment(1) === 'colors' ? 'active' : null); ?>">
        <a class="nav-link" href="<?php echo e(url('colors')); ?>">Colors</a>
      </li>
    </ul>
    <?php if(Route::currentRouteName()== 'vehicles.index'): ?>
    
    <form action="<?php echo e(route('vehicles.index')); ?>" method="GET" role="search" class="form-inline my-2 my-lg-0">
    
    <div class="input-group">
            <input class="form-control mr-sm-2" id="search" name="search" type="search" placeholder="Search" value="<?php echo e(Request::get('search')); ?>" aria-label="Search">
            <button type="submit" class="btn btn-outline-success my-2 my-sm-0">
                Search Vehicles
            </button>
        </span>
    </div>
    </form>
    <?php else: ?>
    <form action="<?php echo e(route('vehicles.index')); ?>" method="GET" role="search" class="form-inline my-2 my-lg-0">
    
    <div class="input-group">
            <input class="form-control mr-sm-2" id="search" name="search" type="search" placeholder="Search" value="<?php echo e(Request::get('search')); ?>" aria-label="Search">
            <button type="submit" class="btn btn-outline-success my-2 my-sm-0">
                Search Vehicles
            </button>
        </span>
    </div>
    </form>
    <?php endif; ?>
  </div>
</nav><?php /**PATH /Applications/MAMP/htdocs/webinteractive/resources/views/nav/nav.blade.php ENDPATH**/ ?>