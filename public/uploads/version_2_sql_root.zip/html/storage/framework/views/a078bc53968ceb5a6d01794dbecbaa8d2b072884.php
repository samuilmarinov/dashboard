<?php $__env->startSection('content'); ?>
        <div class="flex-center position-ref full-height">
            <div class="content">
                <div class="title m-b-md">
                    Dashboard
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/samuilmarinovdev2.co.uk/html/react-rickandmorty/resources/views/dashboard.blade.php ENDPATH**/ ?>