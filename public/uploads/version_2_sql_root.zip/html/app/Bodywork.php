<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bodywork extends Model
{
    protected $fillable = [
        'name', 'status'
    ];

}
